var app = angular
    .module('myApp', ['angularMoment', 'ngMask'])
    .factory('params', function () {

        // valores universais
        return {
            env: 'Modelo 16Apps'
        }

    });

app.controller('appCtrl', function ($scope, $http, params, uteisService) {

    $scope.$watch('$viewContentLoaded', async function () {

        this.options = {
            headers: { 'Content-Type': 'application/json' }
        };

        uteisService.getBase('?c=contas')
            .then((res) => {
                // alert(JSON.stringify(res))
            })
            .catch((error) => {
                // alert(JSON.stringify(error))
            });

        $scope.titulo = params.env

        let reg = {
            _id: '228281'
        };
        uteisService.patchBase('/contas', reg)
            .then((res) => {
                // alert(JSON.stringify(res))
            })
            .catch((error) => {
                // alert(JSON.stringify(error))
            });

    });

    $scope._onMessage = async function () {

        // uteisService.onMsgBox('Olá','teste','error')
        uteisService.onQuestion('Está tudo certo...', 'info', 2000, 'top-end')

    };

});