const mongoose = require('mongoose');
const shortid  = require('shortid');

var Contas = new mongoose.Schema({
    _id: { type: String, 'default': shortid.generate },
    ativo: { type: Number, enum: [0, 1], default: 1 },
    nome: { type: String },
    vinculo_app: { type: Number, enum: [0, 1], default: 0 },

    cnpj_cpf: { type: String },
    cnpj_cpf_vinculado: { type: String  },
    logo: {type: String} ,
    telefone: { type: String },
    email: { type: String},
    endereco: { type: String },
    bairro: { type: String },
    cidade: { type: String },
    estado: { type: String },
    cep: { type: String },
    observacao: { type: String },

    gateway: { type: String },
    gateway_publica: { type: String },
    gateway_secreta: { type: String },

    gateway_tx_transacao: { type: Number, default: 0  },
    gateway_tx_saque: { type: Number, default: 0  },
    gateway_valor_minimo: { type: Number, default: 30  },
    
    saque_nome: { type: String },
    saque_tipo_pessoa: { type: String },
    saque_documento: { type: String },

    saque_tipo_conta: { type: String },
    saque_banco: { type: String },
    saque_agencia: { type: String },
    saque_agencia_digito: { type: String },
    saque_conta: { type: String },
    saque_conta_digito: { type: String },

    saque_chave_pix: { type: String },
    
    id_produto_web: { type: String, ref: 'Produtos' },
    pagto_avulso: { type: Number, default: 0  },
    

    dt_registro: { type: String },
    dt_licenca: { type: String }
}, {
    versionKey: false,
});


module.exports = mongoose.model('Contas', Contas)